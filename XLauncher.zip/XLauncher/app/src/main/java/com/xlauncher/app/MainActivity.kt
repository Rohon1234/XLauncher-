package com.xlauncher.app

import android.app.AlertDialog
import android.app.role.RoleManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognizerIntent
import android.view.DragEvent
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.xlauncher.app.data.AppRef
import com.xlauncher.app.data.HomeItem
import com.xlauncher.app.data.HomeModel
import com.xlauncher.app.data.Launch
import com.xlauncher.app.settings.HomeScreenModeActivity
import com.xlauncher.app.settings.IconStyleActivity
import com.xlauncher.app.settings.SettingsActivity
import com.xlauncher.app.ui.*
import com.xlauncher.app.wallpaper.WallpapersActivity
import java.util.ArrayDeque
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private lateinit var app: LauncherApp
    private val model: HomeModel get() = app.model

    private lateinit var root: HomeRoot
    private lateinit var pager: ViewPager2
    private lateinit var dots: PageDots
    private lateinit var editBar: LinearLayout
    private lateinit var selBar: LinearLayout
    private lateinit var drawer: DrawerView
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager

    private val pageAdapter = PageAdapter()
    private val hostViews = HashMap<Int, AppWidgetHostView>()
    private val selected = LinkedHashSet<Long>()
    private val uninstallQueue = ArrayDeque<String>()

    private var editMode = false
    private var dragging = false
    private var draggingId = -1L
    private var lastFlip = 0L
    private var pageGap = 0f
    private var insTop = 0
    private var insBottom = 0

    private var pendingWidgetId = -1
    private var pendingProvider: AppWidgetProviderInfo? = null

    private val changeListener: () -> Unit = { refreshAll() }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as LauncherApp
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val ctrl = WindowCompat.getInsetsController(window, window.decorView)
        ctrl.isAppearanceLightStatusBars = false
        ctrl.isAppearanceLightNavigationBars = false

        host = AppWidgetHost(this, HOST_ID)
        awm = AppWidgetManager.getInstance(this)
        buildUi()
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val sys = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = ins.getInsets(WindowInsetsCompat.Type.ime())
            applyInsets(sys.left, sys.top, sys.right, sys.bottom, ime.bottom)
            ins
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { onBack() }
        })

        refreshAll()
        if (!app.prefs.askedRole) {
            app.prefs.askedRole = true
            root.post { requestHomeRole() }
        }
    }

    override fun onStart() {
        super.onStart()
        app.addListener(changeListener)
        try { host.startListening() } catch (e: Exception) { }
    }

    override fun onStop() {
        super.onStop()
        app.removeListener(changeListener)
        try { host.stopListening() } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val wasBusy = drawer.isOpen || editMode
        if (drawer.isOpen) drawer.close()
        if (editMode) exitEdit()
        if (!wasBusy) pager.setCurrentItem(0, true)
    }

    private fun onBack() {
        when {
            drawer.isOpen -> drawer.onBack()
            editMode -> exitEdit()
            pager.currentItem != 0 -> pager.setCurrentItem(0, true)
        }
    }

    private fun requestHomeRole() {
        try {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
            }
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ UI construction

    private fun buildUi() {
        root = HomeRoot(this)
        dots = PageDots(this)

        pager = ViewPager2(this)
        pager.offscreenPageLimit = 1
        pager.clipChildren = false
        pager.adapter = pageAdapter
        val rv = pager.getChildAt(0) as RecyclerView
        rv.clipToPadding = false
        rv.clipChildren = false
        rv.overScrollMode = View.OVER_SCROLL_NEVER
        pager.setPageTransformer { page, position -> page.translationX = pageGap * position }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) { dots.current = position }
        })
        root.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))

        root.addView(dots, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        selBar = LinearLayout(this)
        selBar.orientation = LinearLayout.HORIZONTAL
        selBar.setPadding(dp(24), 0, dp(24), 0)
        selBar.visibility = View.GONE
        root.addView(selBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        editBar = buildEditBar()
        root.addView(editBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        drawer = DrawerView(this, app)
        drawer.onOpenSettings = { startActivity(Intent(this, HomeScreenModeActivity::class.java)) }
        drawer.onOpenLauncherSettings = { startActivity(Intent(this, SettingsActivity::class.java)) }
        drawer.onAddToHome = { ref -> addToHome(ref) }
        drawer.onLaunched = { root.postDelayed({ drawer.close() }, 300) }
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))

        root.swipeUpAllowed = { !editMode && !drawer.isOpen && !dragging }
        root.pinchAllowed = { !drawer.isOpen }
        root.onSwipeUp = { drawer.open(false) }
        root.onPinch = { inward -> if (inward) enterEdit() else exitEdit() }
        root.setOnDragListener { _, e -> onDrag(e) }
    }

    private fun buildEditBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER
        bar.visibility = View.GONE

        fun opt(text: String, icon: Int, click: () -> Unit) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setOnClickListener { click() }
            val circle = FrameLayout(this)
            circle.background = oval(0xE62B2B2D.toInt())
            circle.addView(iconView(icon, android.graphics.Color.WHITE), FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
            col.addView(circle, LinearLayout.LayoutParams(dp(64), dp(64)))
            val t = label(text, 14f, android.graphics.Color.WHITE)
            t.maxLines = 1
            t.gravity = Gravity.CENTER
            col.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })
            bar.addView(col, LinearLayout.LayoutParams(dp(82), WRAP))
        }
        opt("Wallpapers", R.drawable.ic_wallpaper) { startActivity(Intent(this, WallpapersActivity::class.java)) }
        opt("Widgets", R.drawable.ic_widgets) { WidgetPicker(this, awm) { p -> addWidget(p) }.show() }
        opt("Icon Style", R.drawable.ic_style) { startActivity(Intent(this, IconStyleActivity::class.java)) }
        opt("Settings", R.drawable.ic_settings) { startActivity(Intent(this, SettingsActivity::class.java)) }
        return bar
    }

    private fun applyInsets(l: Int, t: Int, r: Int, b: Int, imeBottom: Int) {
        insTop = t
        insBottom = b
        val pl = pager.layoutParams as FrameLayout.LayoutParams
        pl.setMargins(l, t, r, b + dp(32))
        pager.layoutParams = pl
        val dl = dots.layoutParams as FrameLayout.LayoutParams
        dl.bottomMargin = b + dp(10)
        dots.layoutParams = dl
        val sl = selBar.layoutParams as FrameLayout.LayoutParams
        sl.topMargin = t + dp(8)
        selBar.layoutParams = sl
        val el = editBar.layoutParams as FrameLayout.LayoutParams
        el.bottomMargin = b + dp(20)
        editBar.layoutParams = el
        drawer.setInsets(l, t, r, max(b, imeBottom))
    }

    // ------------------------------------------------------------------ pages

    private class PageVH(val cell: CellLayout) : RecyclerView.ViewHolder(cell)

    private inner class PageAdapter : RecyclerView.Adapter<PageVH>() {
        override fun getItemCount(): Int = model.pageCount() + if (editMode || dragging) 1 else 0
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val cell = CellLayout(this@MainActivity)
            cell.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
            return PageVH(cell)
        }
        override fun onBindViewHolder(holder: PageVH, position: Int) = bindPage(holder.cell, position)
    }

    private fun refreshAll() {
        if (!::pager.isInitialized) return
        pageAdapter.notifyDataSetChanged()
        dots.count = pageAdapter.itemCount
        if (pager.currentItem >= pageAdapter.itemCount) pager.setCurrentItem(pageAdapter.itemCount - 1, false)
        drawer.refresh()
    }

    private fun bindPage(cell: CellLayout, page: Int) {
        cell.removeAllViews()
        cell.setEdit(editMode)
        cell.onEmptyLongPress = { if (!editMode) enterEdit() }
        cell.onEmptyTap = { if (editMode) exitEdit() }
        for (item in model.itemsOn(page)) {
            if (item.id == draggingId) continue
            val v = createView(item) ?: continue
            cell.addView(v, CellLayout.LP(item.x, item.y, item.spanX, item.spanY))
        }
    }

    private fun createView(item: HomeItem): View? {
        when (item.type) {
            HomeItem.APP -> {
                val ref = item.app ?: return null
                val info = app.apps.find(ref) ?: return null
                val sv = ShortcutView(this, app)
                sv.bindApp(ref, info.label)
                sv.selectable = editMode
                sv.checked = item.id in selected
                sv.setOnClickListener {
                    if (editMode) toggleSelect(item, sv) else Launch.start(this, ref)
                }
                sv.setOnLongClickListener { startDrag(item, sv); true }
                return sv
            }
            HomeItem.FOLDER -> {
                val sv = ShortcutView(this, app)
                sv.bindFolder(item)
                sv.setOnClickListener { if (!editMode) openFolder(item) }
                sv.setOnLongClickListener { startDrag(item, sv); true }
                return sv
            }
            HomeItem.WIDGET -> return widgetView(item)
            HomeItem.SEARCH -> {
                val s = SearchBarView(this)
                s.onSearch = { if (!editMode) drawer.open(true) }
                s.onMic = {
                    try {
                        startActivity(
                            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        )
                    } catch (e: Exception) { }
                }
                s.onLens = {
                    packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
                        ?.let { startActivity(it) }
                }
                attachLongPress(s, item)
                return s
            }
            HomeItem.CLOCK -> {
                val c = ClockView(this)
                attachLongPress(c, item)
                return c
            }
        }
        return null
    }

    private fun attachLongPress(v: View, item: HomeItem) {
        v.setOnLongClickListener { showItemMenu(item, v); true }
    }

    private fun widgetView(item: HomeItem): View? {
        val info = awm.getAppWidgetInfo(item.widgetId) ?: return null
        val hv = hostViews.getOrPut(item.widgetId) { host.createView(this, item.widgetId, info) }
        (hv.parent as? ViewGroup)?.removeView(hv)
        val frame = WidgetFrame(this)
        frame.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.onLongPress = { showItemMenu(item, frame) }
        return frame
    }

    // ------------------------------------------------------------------ edit mode & selection

    private fun enterEdit() {
        if (editMode) return
        editMode = true
        selected.clear()
        pageAdapter.notifyDataSetChanged()
        dots.count = pageAdapter.itemCount
        dots.visibility = View.INVISIBLE
        editBar.visibility = View.VISIBLE
        editBar.alpha = 0f
        editBar.translationY = dp(40).toFloat()
        editBar.animate().alpha(1f).translationY(0f).setDuration(220).start()
        animateWorkspace(true)
        updateSelBar()
        root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun exitEdit() {
        if (!editMode) return
        editMode = false
        selected.clear()
        model.compact()
        model.save()
        pageAdapter.notifyDataSetChanged()
        dots.count = pageAdapter.itemCount
        dots.visibility = View.VISIBLE
        if (pager.currentItem >= pageAdapter.itemCount) pager.setCurrentItem(pageAdapter.itemCount - 1, false)
        editBar.animate().alpha(0f).translationY(dp(40).toFloat()).setDuration(180)
            .withEndAction { if (!editMode) editBar.visibility = View.GONE }.start()
        animateWorkspace(false)
        updateSelBar()
    }

    private fun animateWorkspace(edit: Boolean) {
        val ph = pager.height
        if (ph == 0) return
        if (edit) {
            val availTop = insTop + dp(96)
            val availBottom = root.height - insBottom - dp(150)
            val s = min(0.86f, (availBottom - availTop).toFloat() / ph)
            val centerDesired = (availTop + availBottom) / 2f
            val centerNow = insTop + ph / 2f
            pageGap = dp(14) / s
            pager.pivotX = pager.width / 2f
            pager.pivotY = ph / 2f
            pager.animate().scaleX(s).scaleY(s).translationY(centerDesired - centerNow).setDuration(250).start()
        } else {
            pageGap = 0f
            pager.animate().scaleX(1f).scaleY(1f).translationY(0f).setDuration(220).start()
        }
        pager.requestTransform()
    }

    private fun toggleSelect(item: HomeItem, sv: ShortcutView) {
        if (!selected.add(item.id)) selected.remove(item.id)
        sv.checked = item.id in selected
        updateSelBar()
    }

    private fun barButton(text: String, icon: Int, click: () -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, dp(6), 0, dp(6))
        col.setOnClickListener { click() }
        col.addView(iconView(icon, android.graphics.Color.WHITE), LinearLayout.LayoutParams(dp(28), dp(28)))
        col.addView(label(text, 14f, android.graphics.Color.WHITE), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        return col
    }

    private fun updateSelBar() {
        selBar.removeAllViews()
        val n = selected.size
        if (!editMode || n == 0) {
            selBar.visibility = View.GONE
            return
        }
        selBar.visibility = View.VISIBLE
        val w = LinearLayout.LayoutParams(0, WRAP, 1f)
        if (n >= 2) selBar.addView(barButton("Group", R.drawable.ic_group) { groupSelected() }, w)
        selBar.addView(barButton("Remove", R.drawable.ic_remove) { removeSelected() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        selBar.addView(barButton("Uninstall", R.drawable.ic_uninstall) { uninstallSelected() }, LinearLayout.LayoutParams(0, WRAP, 1f))
    }

    private fun groupSelected() {
        val apps = selected.mapNotNull { model.get(it) }.filter { it.type == HomeItem.APP }
        if (apps.size < 2) return
        val first = apps.first()
        val folder = HomeItem(app.prefs.nextId(), HomeItem.FOLDER, first.page, first.x, first.y)
        folder.title = "Folder"
        apps.forEach { a -> a.app?.let { folder.children.add(it) } }
        model.items.removeAll(apps.toSet())
        model.items.add(folder)
        selected.clear()
        model.save()
        pageAdapter.notifyDataSetChanged()
        updateSelBar()
    }

    private fun removeSelected() {
        selected.forEach { model.removeById(it) }
        selected.clear()
        model.save()
        pageAdapter.notifyDataSetChanged()
        updateSelBar()
    }

    private fun uninstallSelected() {
        val pkgs = selected.mapNotNull { model.get(it)?.app?.pkg }.distinct()
        selected.clear()
        uninstallQueue.clear()
        uninstallQueue.addAll(pkgs)
        pageAdapter.notifyDataSetChanged()
        updateSelBar()
        nextUninstall()
    }

    private fun nextUninstall() {
        val pkg = uninstallQueue.poll() ?: return
        try {
            val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            i.putExtra(Intent.EXTRA_RETURN_RESULT, true)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_UNINSTALL)
        } catch (e: Exception) {
            nextUninstall()
        }
    }

    // ------------------------------------------------------------------ folders & item menus

    private fun openFolder(item: HomeItem) {
        FolderDialog(this, app, item) { pageAdapter.notifyDataSetChanged() }.show()
    }

    private fun showItemMenu(item: HomeItem, anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Move")
        if (item.type == HomeItem.WIDGET) m.menu.add(0, 2, 1, "Resize")
        m.menu.add(0, 3, 2, "Remove")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> startDrag(item, anchor)
                2 -> resizeWidget(item)
                3 -> {
                    if (item.type == HomeItem.WIDGET) {
                        try { host.deleteAppWidgetId(item.widgetId) } catch (e: Exception) { }
                        hostViews.remove(item.widgetId)
                    }
                    model.removeById(item.id)
                    model.save()
                    pageAdapter.notifyDataSetChanged()
                }
            }
            true
        }
        m.show()
    }

    private fun addToHome(ref: AppRef) {
        if (model.addApp(ref) == null) {
            Toast.makeText(this, "Already on Home screen", Toast.LENGTH_SHORT).show()
        } else {
            model.save()
            refreshAll()
            Toast.makeText(this, "Added to Home screen", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ drag & drop

    private fun startDrag(item: HomeItem, v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        draggingId = item.id
        dragging = true
        val data = ClipData.newPlainText("item", item.id.toString())
        v.startDragAndDrop(data, View.DragShadowBuilder(v), item.id, 0)
        pageAdapter.notifyDataSetChanged()
        dots.count = pageAdapter.itemCount
    }

    private fun onDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> return e.localState is Long
            DragEvent.ACTION_DRAG_LOCATION -> { handleEdge(e.x); return true }
            DragEvent.ACTION_DROP -> { handleDrop(e); return true }
            DragEvent.ACTION_DRAG_ENDED -> { endDrag(); return true }
        }
        return true
    }

    private fun handleEdge(x: Float) {
        val now = SystemClock.uptimeMillis()
        if (now - lastFlip < 700) return
        val edge = dp(40)
        if (x < edge && pager.currentItem > 0) {
            pager.setCurrentItem(pager.currentItem - 1, true); lastFlip = now
        } else if (x > root.width - edge && pager.currentItem < pageAdapter.itemCount - 1) {
            pager.setCurrentItem(pager.currentItem + 1, true); lastFlip = now
        }
    }

    private fun handleDrop(e: DragEvent) {
        val id = e.localState as? Long ?: return
        val item = model.get(id) ?: return
        val page = pager.currentItem
        val rv = pager.getChildAt(0) as RecyclerView
        val holder = rv.findViewHolderForAdapterPosition(page) as? PageVH ?: return
        val cell = holder.cell
        val rootLoc = IntArray(2)
        val cellLoc = IntArray(2)
        root.getLocationOnScreen(rootLoc)
        cell.getLocationOnScreen(cellLoc)
        val sx = if (pager.scaleX > 0f) pager.scaleX else 1f
        val sy = if (pager.scaleY > 0f) pager.scaleY else 1f
        val lx = (e.x + rootLoc[0] - cellLoc[0]) / sx
        val ly = (e.y + rootLoc[1] - cellLoc[1]) / sy
        val (rawX, rawY) = cell.cellAt(lx, ly)
        val cx = rawX.coerceAtMost(HomeModel.COLS - item.spanX).coerceAtLeast(0)
        val cy = rawY.coerceAtMost(HomeModel.ROWS - item.spanY).coerceAtLeast(0)

        if (model.isFree(page, cx, cy, item.spanX, item.spanY, id)) {
            item.page = page; item.x = cx; item.y = cy
            return
        }
        val occ = model.itemAt(page, rawX, rawY, id) ?: return
        if (item.type != HomeItem.APP) return
        val dragged = item.app ?: return
        if (occ.type == HomeItem.APP) {
            val target = occ.app ?: return
            val folder = HomeItem(app.prefs.nextId(), HomeItem.FOLDER, occ.page, occ.x, occ.y)
            folder.title = "Folder"
            folder.children.add(target)
            folder.children.add(dragged)
            model.items.remove(occ)
            model.items.remove(item)
            model.items.add(folder)
        } else if (occ.type == HomeItem.FOLDER) {
            occ.children.add(dragged)
            model.items.remove(item)
        }
    }

    private fun endDrag() {
        draggingId = -1L
        dragging = false
        if (!editMode) model.compact()
        model.save()
        pageAdapter.notifyDataSetChanged()
        dots.count = pageAdapter.itemCount
        if (pager.currentItem >= pageAdapter.itemCount) pager.setCurrentItem(pageAdapter.itemCount - 1, false)
    }

    // ------------------------------------------------------------------ widgets

    private fun spanFor(info: AppWidgetProviderInfo): Pair<Int, Int> {
        val cw = max(1, (pager.width - dp(20)) / HomeModel.COLS)
        val ch = max(1, (pager.height - dp(20)) / HomeModel.ROWS)
        var sx = ceil(info.minWidth / cw.toFloat()).toInt()
        var sy = ceil(info.minHeight / ch.toFloat()).toInt()
        if (info.targetCellWidth > 0) sx = info.targetCellWidth
        if (info.targetCellHeight > 0) sy = info.targetCellHeight
        return Pair(sx.coerceIn(1, HomeModel.COLS), sy.coerceIn(1, HomeModel.ROWS))
    }

    private fun addWidget(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingWidgetId = id
        pendingProvider = p
        if (awm.bindAppWidgetIdIfAllowed(id, p.provider)) {
            onWidgetBound(id, p)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_BIND)
            } catch (e: Exception) {
                cancelPending()
            }
        }
    }

    private fun onWidgetBound(id: Int, p: AppWidgetProviderInfo) {
        if (p.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
            } catch (e: Exception) {
                finishAddWidget(id, p)
            }
        } else {
            finishAddWidget(id, p)
        }
    }

    private fun finishAddWidget(id: Int, p: AppWidgetProviderInfo) {
        val (sx, sy) = spanFor(p)
        val item = HomeItem(app.prefs.nextId(), HomeItem.WIDGET, 0, 0, 0, sx, sy)
        item.widgetId = id
        model.placeAnywhere(item, pager.currentItem)
        model.items.add(item)
        model.save()
        pageAdapter.notifyDataSetChanged()
        dots.count = pageAdapter.itemCount
        pager.setCurrentItem(item.page, false)
        pendingWidgetId = -1
        pendingProvider = null
    }

    private fun cancelPending() {
        if (pendingWidgetId != -1) {
            try { host.deleteAppWidgetId(pendingWidgetId) } catch (e: Exception) { }
        }
        pendingWidgetId = -1
        pendingProvider = null
    }

    private fun resizeWidget(item: HomeItem) {
        val sizes = listOf(
            Pair(1, 1), Pair(2, 1), Pair(2, 2), Pair(3, 1), Pair(3, 2),
            Pair(4, 1), Pair(4, 2), Pair(4, 3), Pair(4, 4)
        )
        val labels = sizes.map { "${it.first} x ${it.second}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Resize widget")
            .setItems(labels) { _, which ->
                val (w, h) = sizes[which]
                if (model.isFree(item.page, item.x, item.y, w, h, item.id)) {
                    item.spanX = w; item.spanY = h
                    model.save()
                    pageAdapter.notifyDataSetChanged()
                } else {
                    Toast.makeText(this, "Not enough space", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_BIND -> {
                val p = pendingProvider
                if (resultCode == RESULT_OK && p != null) onWidgetBound(pendingWidgetId, p) else cancelPending()
            }
            REQ_CONFIG -> {
                val p = pendingProvider
                if (resultCode == RESULT_OK && p != null) finishAddWidget(pendingWidgetId, p) else cancelPending()
            }
            REQ_UNINSTALL -> nextUninstall()
        }
    }

    companion object {
        private const val HOST_ID = 1024
        private const val REQ_BIND = 9001
        private const val REQ_CONFIG = 9002
        private const val REQ_UNINSTALL = 9003
    }
}
