package com.xlauncher.app.ui

import android.appwidget.AppWidgetHostView
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import com.xlauncher.app.R
import kotlin.math.abs

/** Wraps an AppWidgetHostView and reports long presses (child still gets normal touches). */
class WidgetFrame(ctx: Context) : FrameLayout(ctx) {
    var onLongPress: (() -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private var fired = false
    private var dx = 0f
    private var dy = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val task = Runnable { fired = true; onLongPress?.invoke() }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                fired = false
                dx = e.x; dy = e.y
                handler.postDelayed(task, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE ->
                if (abs(e.x - dx) > slop || abs(e.y - dy) > slop) handler.removeCallbacks(task)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(task)
        }
        return fired
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = fired || super.onTouchEvent(event)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val hv = getChildAt(0) as? AppWidgetHostView ?: return
        val wd = (w / resources.displayMetrics.density).toInt()
        val hd = (h / resources.displayMetrics.density).toInt()
        try { hv.updateAppWidgetSize(null, wd, hd, wd, hd) } catch (e: Exception) { }
    }
}

/** Google-style search pill shown on the home screen. */
class SearchBarView(ctx: Context) : FrameLayout(ctx) {
    var onSearch: (() -> Unit)? = null
    var onMic: (() -> Unit)? = null
    var onLens: (() -> Unit)? = null

    init {
        val pill = LinearLayout(ctx)
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = roundRect(0xB32B2B2D.toInt(), dp(30f).toFloat())
        pill.setPadding(dp(18), 0, dp(14), 0)
        pill.setOnClickListener { onSearch?.invoke() }

        val g = TextView(ctx)
        g.text = "G"
        g.textSize = 26f
        g.typeface = Typeface.DEFAULT_BOLD
        g.paint.shader = LinearGradient(
            0f, 0f, 0f, 60f,
            intArrayOf(0xFF4285F4.toInt(), 0xFFEA4335.toInt(), 0xFFFBBC05.toInt(), 0xFF34A853.toInt()),
            floatArrayOf(0f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        pill.addView(g, LinearLayout.LayoutParams(WRAP, WRAP))
        pill.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))

        val mic = ctx.iconView(R.drawable.ic_mic, 0xFFE8E8E8.toInt())
        mic.setOnClickListener { onMic?.invoke() }
        pill.addView(mic, LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(18) })
        val lens = ctx.iconView(R.drawable.ic_camera, 0xFFE8E8E8.toInt())
        lens.setOnClickListener { onLens?.invoke() }
        pill.addView(lens, LinearLayout.LayoutParams(dp(26), dp(26)))

        val lp = LayoutParams(MATCH, dp(54), Gravity.CENTER_VERTICAL)
        lp.setMargins(dp(8), 0, dp(8), 0)
        addView(pill, lp)
    }
}

/** Live clock + date (hour big, minutes small, date on the right). */
class ClockView(ctx: Context) : FrameLayout(ctx) {
    init {
        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), 0, dp(14), 0)

        val hour = TextClock(ctx)
        hour.format24Hour = "HH"
        hour.format12Hour = "hh"
        hour.textSize = 78f
        hour.setTextColor(Color.WHITE)
        hour.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        hour.includeFontPadding = false
        row.addView(hour, LinearLayout.LayoutParams(WRAP, WRAP))

        val min = TextClock(ctx)
        min.format24Hour = "mm"
        min.format12Hour = "mm"
        min.textSize = 34f
        min.setTextColor(Color.WHITE)
        min.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        min.includeFontPadding = false
        val mlp = LinearLayout.LayoutParams(WRAP, WRAP)
        mlp.leftMargin = dp(8)
        mlp.bottomMargin = dp(30)
        row.addView(min, mlp)

        row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))

        val date = TextClock(ctx)
        date.format24Hour = "EEE, MMM d"
        date.format12Hour = "EEE, MMM d"
        date.textSize = 16f
        date.setTextColor(Color.WHITE)
        date.setShadowLayer(4f, 0f, 1f, 0x66000000)
        row.addView(date, LinearLayout.LayoutParams(WRAP, WRAP))

        addView(row, LayoutParams(MATCH, MATCH))
        setOnClickListener {
            try {
                ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) { }
        }
    }
}

class PageDots(ctx: Context) : View(ctx) {
    var count = 1
        set(v) { field = v; requestLayout(); invalidate() }
    var current = 0
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(count * dp(14), dp(14))
    }

    override fun onDraw(c: Canvas) {
        for (i in 0 until count) {
            p.color = if (i == current) Color.WHITE else 0x66FFFFFF
            c.drawCircle(dp(7) + i * dp(14).toFloat(), height / 2f, if (i == current) dp(3.5f).toFloat() else dp(3f).toFloat(), p)
        }
    }
}
