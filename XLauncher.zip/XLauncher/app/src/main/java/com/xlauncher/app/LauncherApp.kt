package com.xlauncher.app

import android.app.Application
import android.content.pm.LauncherApps
import android.os.Handler
import android.os.Looper
import android.os.UserHandle
import com.xlauncher.app.data.AppRepository
import com.xlauncher.app.data.HomeModel
import com.xlauncher.app.data.IconCache
import com.xlauncher.app.data.Prefs
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class LauncherApp : Application() {
    lateinit var prefs: Prefs
    lateinit var apps: AppRepository
    lateinit var icons: IconCache
    lateinit var model: HomeModel

    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    private val reloadTask = Runnable {
        worker.execute {
            apps.reload()
            main.post {
                icons.clear()
                syncHome()
                listeners.forEach { it() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        apps = AppRepository(this)
        icons = IconCache(this, prefs)
        model = HomeModel(prefs)
        apps.reload()
        model.load()
        syncHome()
        try {
            val la = getSystemService(LauncherApps::class.java)
            la.registerCallback(object : LauncherApps.Callback() {
                override fun onPackageRemoved(packageName: String?, user: UserHandle?) = packagesChanged()
                override fun onPackageAdded(packageName: String?, user: UserHandle?) = packagesChanged()
                override fun onPackageChanged(packageName: String?, user: UserHandle?) = packagesChanged()
                override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = packagesChanged()
                override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = packagesChanged()
            }, main)
        } catch (e: Exception) {
        }
    }

    private fun packagesChanged() {
        main.removeCallbacks(reloadTask)
        main.postDelayed(reloadTask, 400)
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Keeps the home layout consistent with installed apps. */
    fun syncHome() {
        val current = apps.apps
        val keys = current.map { it.ref.key }.toSet()
        if (current.isEmpty()) return
        if (!prefs.seeded) {
            model.seed(current)
            prefs.seeded = true
        } else {
            model.removeMissing(keys)
            if (prefs.addNewApps) {
                val known = prefs.knownApps
                current.filter { it.ref.key !in known }.forEach { model.addApp(it.ref) }
            }
        }
        prefs.knownApps = keys
        model.save()
    }
}
