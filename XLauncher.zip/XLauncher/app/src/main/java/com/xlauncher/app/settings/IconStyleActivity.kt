package com.xlauncher.app.settings

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.data.IconShaper
import com.xlauncher.app.ui.*

class IconStyleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as LauncherApp
        val prefs = app.prefs
        val body = scaffold("Icon Style")

        val names = listOf("Original", "Circle", "Squircle", "Rounded Square", "Square")
        val samples = app.apps.apps.take(4).map { app.icons.rawDrawable(it.ref) }
        val dots = names.map { RadioDot(this) }

        fun renderDots() { dots.forEachIndexed { i, d -> d.checked = prefs.iconStyle == i } }

        val styleCard = card()
        names.forEachIndexed { i, name ->
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(20), dp(14), dp(20), dp(14))
            row.setOnClickListener {
                prefs.iconStyle = i
                app.icons.clear()
                renderDots()
            }
            row.addView(label(name, 17f, C.TEXT), LinearLayout.LayoutParams(0, WRAP, 1f))
            for (d in samples) {
                val iv = ImageView(this)
                val copy = d.constantState?.newDrawable()?.mutate() ?: d
                iv.setImageBitmap(IconShaper.render(copy, 96, i))
                row.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
            }
            row.addView(dots[i], LinearLayout.LayoutParams(dp(24), dp(24)).apply { leftMargin = dp(8) })
            styleCard.addView(row)
        }
        body.addView(styleCard)

        body.addView(label("Icon Size", 15f, C.GRAY).apply { setPadding(dp(24), dp(16), dp(24), dp(4)) })
        val sizeCard = card()
        val seg = LinearLayout(this)
        seg.setPadding(dp(8), dp(8), dp(8), dp(8))
        val sizeNames = listOf("Small", "Medium", "Large")
        val tvs = ArrayList<TextView>()
        fun renderSizes() {
            tvs.forEachIndexed { i, t ->
                val on = prefs.iconSize == i
                t.setTextColor(if (on) Color.WHITE else C.TEXT)
                t.background = if (on) roundRect(C.BLUE, dp(14f).toFloat()) else null
            }
        }
        sizeNames.forEachIndexed { i, n ->
            val t = label(n, 16f, C.TEXT, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener { prefs.iconSize = i; renderSizes() }
            tvs.add(t)
            seg.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        sizeCard.addView(seg)
        body.addView(sizeCard)

        renderDots()
        renderSizes()
    }
}
