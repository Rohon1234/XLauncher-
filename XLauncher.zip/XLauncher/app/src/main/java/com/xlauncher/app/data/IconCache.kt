package com.xlauncher.app.data

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

class IconCache(private val ctx: Context, private val prefs: Prefs) {
    private val cache = LruCache<String, Bitmap>(400)
    private val executor = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())
    private val sizePx = 192

    private fun key(ref: AppRef) = "${ref.key}#${prefs.iconStyle}"

    fun peek(ref: AppRef): Bitmap? = cache.get(key(ref))

    fun rawDrawable(ref: AppRef): Drawable {
        val pm = ctx.packageManager
        return try {
            pm.getActivityInfo(ComponentName(ref.pkg, ref.cls), 0).loadIcon(pm)
        } catch (e: Exception) {
            pm.defaultActivityIcon
        }
    }

    private fun build(ref: AppRef): Bitmap = IconShaper.render(rawDrawable(ref), sizePx, prefs.iconStyle)

    fun loadSync(ref: AppRef): Bitmap {
        peek(ref)?.let { return it }
        val b = build(ref)
        cache.put(key(ref), b)
        return b
    }

    fun load(ref: AppRef, cb: (Bitmap) -> Unit) {
        val cached = peek(ref)
        if (cached != null) { cb(cached); return }
        val k = key(ref)
        executor.execute {
            val b = build(ref)
            cache.put(k, b)
            main.post { cb(b) }
        }
    }

    fun clear() = cache.evictAll()
}

object IconShaper {
    fun render(d: Drawable, size: Int, style: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (style == 0) {
            d.setBounds(0, 0, size, size)
            d.draw(c)
            return bmp
        }
        c.save()
        c.clipPath(shape(style, size.toFloat()))
        if (d is AdaptiveIconDrawable) {
            val off = (size * 0.25f).toInt()
            d.background?.let { it.setBounds(-off, -off, size + off, size + off); it.draw(c) }
            d.foreground?.let { it.setBounds(-off, -off, size + off, size + off); it.draw(c) }
        } else {
            d.setBounds(0, 0, size, size)
            d.draw(c)
        }
        c.restore()
        return bmp
    }

    fun shape(style: Int, s: Float): Path {
        val p = Path()
        when (style) {
            1 -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
            2 -> {
                val n = 4.0
                val steps = 72
                for (i in 0..steps) {
                    val t = 2.0 * Math.PI * i / steps
                    val ct = cos(t); val st = sin(t)
                    val x = s / 2 + (s / 2) * sgn(ct) * abs(ct).pow(2.0 / n).toFloat()
                    val y = s / 2 + (s / 2) * sgn(st) * abs(st).pow(2.0 / n).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            3 -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.26f, s * 0.26f, Path.Direction.CW)
            else -> p.addRoundRect(RectF(0f, 0f, s, s), s * 0.04f, s * 0.04f, Path.Direction.CW)
        }
        return p
    }

    private fun sgn(v: Double): Float = if (v < 0) -1f else 1f
}
