package com.xlauncher.app.wallpaper

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.MainActivity
import com.xlauncher.app.R
import com.xlauncher.app.ui.*

class RoundImageView(ctx: Context, private val radius: Float) : ImageView(ctx) {
    init {
        scaleType = ScaleType.CENTER_CROP
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        setBackgroundColor(0xFFE4E4E8.toInt())
    }
}

/** Applies a static wallpaper in the background and returns to the Home screen. */
fun ComponentActivity.applyEntryAndGoHome(e: WallpaperEntry) {
    val app = application as LauncherApp
    val (w, h) = WallpaperRepo.screenSize(this)
    Toast.makeText(this, "Applying...", Toast.LENGTH_SHORT).show()
    Thread {
        val ok = try {
            WallpaperRepo.apply(this, WallpaperRepo.render(this, e, w, h))
        } catch (ex: Exception) {
            false
        }
        runOnUiThread {
            if (ok) {
                app.prefs.wallpaperId = e.id
                goHome()
            } else {
                Toast.makeText(this, "Could not apply wallpaper", Toast.LENGTH_SHORT).show()
            }
        }
    }.start()
}

fun ComponentActivity.goHome() {
    startActivity(
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    )
}

class WallpapersActivity : ComponentActivity() {
    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            startActivity(
                Intent(this, WallpaperPreviewActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val body = scaffold("Wallpapers")
        val entries = WallpaperRepo.list(this)

        fun sourceCard(text: String, icon: Int, c1: Int, c2: Int, click: () -> Unit): View {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER
            card.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
                cornerRadius = dp(20f).toFloat()
            }
            card.setOnClickListener { click() }
            card.addView(iconView(icon, Color.WHITE), LinearLayout.LayoutParams(dp(34), dp(34)))
            val t = label(text, 15f, Color.WHITE)
            t.gravity = Gravity.CENTER
            card.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(8) })
            return card
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(16), dp(8), dp(16), dp(8))
        row.addView(
            sourceCard("Gallery", R.drawable.ic_gallery, 0xFFFFC04D.toInt(), 0xFFF7A021.toInt()) {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            LinearLayout.LayoutParams(0, dp(110), 1f).apply { rightMargin = dp(6) }
        )
        row.addView(
            sourceCard("Static Wallpapers", R.drawable.ic_image, 0xFF6C9BFF.toInt(), 0xFF3D6BF7.toInt()) {
                startActivity(Intent(this, StaticWallpaperActivity::class.java))
            },
            LinearLayout.LayoutParams(0, dp(110), 1f).apply { leftMargin = dp(6) }
        )
        body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        // "Static Wallpapers  19  >" row
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(20), dp(18), dp(16), dp(10))
        head.setOnClickListener { startActivity(Intent(this, StaticWallpaperActivity::class.java)) }
        head.addView(label("Static Wallpapers", 18f, C.TEXT))
        head.addView(
            label(entries.size.toString(), 14f, C.GRAY),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(8) }
        )
        head.addView(iconView(R.drawable.ic_chevron, C.GRAY), LinearLayout.LayoutParams(dp(22), dp(22)))
        body.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rv.setPadding(dp(16), 0, dp(8), 0)
        rv.clipToPadding = false
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount(): Int = entries.size
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val iv = RoundImageView(this@WallpapersActivity, dp(16f).toFloat())
                iv.layoutParams = RecyclerView.LayoutParams(dp(100), dp(222)).apply { rightMargin = dp(8) }
                return object : RecyclerView.ViewHolder(iv) {}
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val e = entries[position]
                val iv = holder.itemView as ImageView
                Thumbs.load(this@WallpapersActivity, e, iv)
                iv.setOnClickListener { applyEntryAndGoHome(e) }
            }
        }
        body.addView(rv, LinearLayout.LayoutParams(MATCH, dp(222)))
    }
}
