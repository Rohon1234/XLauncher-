package com.xlauncher.app.wallpaper

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.sin

/** Procedurally drawn built-in wallpapers (19 of them). */
object WallpaperFactory {
    const val COUNT = 19

    private fun hsv(h: Float, s: Float, v: Float, a: Int = 255): Int =
        Color.HSVToColor(a, floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

    // bgTop, bgBottom, ribbonA, ribbonB, highlight
    private val RIBBON = arrayOf(
        longArrayOf(0xFFDCD6FF, 0xFFA98BFF, 0xFFFF40E8, 0xFF6A38FF, 0xFFE8CCFF),
        longArrayOf(0xFFD6DDD8, 0xFF9FD9AE, 0xFFA6F000, 0xFF2FE08A, 0xFFE3FFB0),
        longArrayOf(0xFFBDB0B9, 0xFF8B7F93, 0xFFF2EEF6, 0xFF8E7FA6, 0xFFFFE96B),
        longArrayOf(0xFF1B1B1D, 0xFF050506, 0xFFE9E6DC, 0xFF5C5C60, 0xFFFFD84D)
    )

    fun render(index: Int, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        when {
            index < 4 -> ribbon(c, w, h, index)
            index < 9 -> orbs(c, w, h, index - 4)
            index < 14 -> pattern(c, w, h, index - 9)
            else -> aurora(c, w, h, index - 14)
        }
        return bmp
    }

    private fun ribbon(c: Canvas, w: Int, h: Int, i: Int) {
        val p = RIBBON[i].map { it.toInt() }
        val W = w.toFloat()
        val H = h.toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, 0f, H, p[0], p[1], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, paint)
        paint.shader = null

        val slab1 = RectF(-0.2f * W, 0.10f * H, 0.98f * W, 0.43f * H)
        val slab2 = RectF(0.02f * W, 0.56f * H, 1.2f * W, 0.90f * H)
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(70, 255, 255, 255)
        c.drawRoundRect(slab1, 0.2f * W, 0.2f * W, paint)
        c.drawRoundRect(slab2, 0.2f * W, 0.2f * W, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.004f * W
        paint.color = Color.argb(120, 255, 255, 255)
        c.drawRoundRect(slab1, 0.2f * W, 0.2f * W, paint)
        c.drawRoundRect(slab2, 0.2f * W, 0.2f * W, paint)

        val path = Path()
        path.moveTo(1.02f * W, 0.12f * H)
        path.cubicTo(0.98f * W, 0.30f * H, 0.80f * W, 0.44f * H, 0.45f * W, 0.465f * H)
        path.cubicTo(0.10f * W, 0.49f * H, -0.04f * W, 0.60f * H, 0.08f * W, 0.74f * H)
        path.cubicTo(0.20f * W, 0.89f * H, 0.60f * W, 0.91f * H, 1.02f * W, 0.86f * H)

        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 0.13f * W
        paint.color = Color.argb(50, 0, 0, 0)
        paint.maskFilter = BlurMaskFilter(0.04f * W, BlurMaskFilter.Blur.NORMAL)
        c.save()
        c.translate(0f, 0.01f * H)
        c.drawPath(path, paint)
        c.restore()
        paint.maskFilter = null

        paint.strokeWidth = 0.11f * W
        paint.shader = LinearGradient(0f, 0.1f * H, 0f, 0.9f * H, p[2], p[3], Shader.TileMode.CLAMP)
        c.drawPath(path, paint)
        paint.shader = null

        paint.strokeWidth = 0.014f * W
        paint.color = Color.argb(200, Color.red(p[4]), Color.green(p[4]), Color.blue(p[4]))
        c.save()
        c.translate(-0.025f * W, 0f)
        c.drawPath(path, paint)
        c.restore()
    }

    private fun orbs(c: Canvas, w: Int, h: Int, i: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        val base = i * 62f + 15f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(
            0f, 0f, W, H, hsv(base, 0.25f, 0.98f), hsv(base + 30f, 0.55f, 0.75f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, W, H, paint)
        val specs = arrayOf(
            floatArrayOf(0.25f, 0.22f, 0.34f),
            floatArrayOf(0.78f, 0.50f, 0.40f),
            floatArrayOf(0.30f, 0.78f, 0.36f)
        )
        for ((idx, s) in specs.withIndex()) {
            val cx = s[0] * W
            val cy = s[1] * H
            val r = s[2] * W
            val hue = base + idx * 35f
            paint.shader = RadialGradient(
                cx - r * 0.35f, cy - r * 0.4f, r * 1.4f,
                intArrayOf(hsv(hue, 0.15f, 1f), hsv(hue, 0.65f, 0.95f), hsv(hue + 10f, 0.9f, 0.55f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, cy, r, paint)
            paint.shader = null
            paint.color = Color.argb(110, 255, 255, 255)
            c.drawOval(RectF(cx - r * 0.55f, cy - r * 0.8f, cx + r * 0.05f, cy - r * 0.45f), paint)
        }
    }

    private fun star(cx: Float, cy: Float, r: Float): Path {
        val p = Path()
        for (k in 0 until 10) {
            val rr = if (k % 2 == 0) r else r * 0.45f
            val a = Math.PI / 5.0 * k - Math.PI / 2.0
            val x = cx + rr * cos(a).toFloat()
            val y = cy + rr * sin(a).toFloat()
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    private fun pattern(c: Canvas, w: Int, h: Int, i: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        val hue = i * 72f + 20f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = hsv(hue, 0.35f, 0.95f)
        c.drawRect(0f, 0f, W, H, paint)
        val cell = W / 4f
        var row = 0
        var y = cell * 0.6f
        while (y < H + cell) {
            for (col in 0..4) {
                val x = col * cell + if (row % 2 == 0) 0f else cell / 2f
                val k = (row + col + i) % 4
                paint.color = hsv(hue + 40f * ((row + col) % 4), 0.55f, 0.92f)
                val s = cell * 0.30f
                when (k) {
                    0 -> c.drawCircle(x, y, s, paint)
                    1 -> c.drawRoundRect(RectF(x - s, y - s, x + s, y + s), s * 0.4f, s * 0.4f, paint)
                    2 -> c.drawPath(star(x, y, s * 1.15f), paint)
                    else -> {
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = s * 0.35f
                        c.drawCircle(x, y, s * 0.85f, paint)
                        paint.style = Paint.Style.FILL
                    }
                }
            }
            row++
            y += cell * 0.9f
        }
    }

    private fun aurora(c: Canvas, w: Int, h: Int, i: Int) {
        val W = w.toFloat()
        val H = h.toFloat()
        val base = i * 70f + 200f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, W, H, hsv(base, 0.7f, 0.20f), hsv(base + 40f, 0.8f, 0.07f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, paint)
        val xs = floatArrayOf(0.2f, 0.85f, 0.35f, 0.9f)
        val ys = floatArrayOf(0.15f, 0.35f, 0.65f, 0.9f)
        for (k in 0 until 4) {
            val cx = xs[k] * W
            val cy = ys[k] * H
            val rad = W * (0.7f + 0.1f * k)
            paint.shader = RadialGradient(
                cx, cy, rad,
                hsv(base + k * 45f, 0.8f, 0.95f, 190), hsv(base + k * 45f, 0.8f, 0.95f, 0),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, W, H, paint)
        }
    }
}
