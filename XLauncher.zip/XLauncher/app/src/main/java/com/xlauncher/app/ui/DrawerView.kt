package com.xlauncher.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.R
import com.xlauncher.app.data.AppInfo
import com.xlauncher.app.data.AppRef
import com.xlauncher.app.data.AppRepository
import com.xlauncher.app.data.Launch
import com.xlauncher.app.data.Prefs
import kotlin.math.max
import kotlin.math.min

class AlphabetStrip(ctx: Context) : View(ctx) {
    var letters: List<Char> = emptyList()
        set(v) { field = v; invalidate() }
    var horizontal = false
        set(v) { field = v; invalidate() }
    var active: Char? = null
        set(v) { if (field != v) { field = v; invalidate() } }
    var onLetter: ((Char) -> Unit)? = null
    private var last = -1
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        paint.textSize = dp(12f).toFloat()
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.DEFAULT_BOLD
    }

    private fun step(total: Int): Float = min(total.toFloat() / max(1, letters.size), dp(18f).toFloat())

    override fun onDraw(c: Canvas) {
        if (letters.isEmpty()) return
        val n = letters.size
        val off = paint.textSize / 3f
        if (!horizontal) {
            val s = step(height)
            val top = (height - s * n) / 2f
            for (i in 0 until n) {
                paint.color = if (letters[i] == active) C.BLUE else Color.WHITE
                c.drawText(letters[i].toString(), width / 2f, top + s * (i + 0.5f) + off, paint)
            }
        } else {
            val s = step(width)
            val left = (width - s * n) / 2f
            for (i in 0 until n) {
                paint.color = if (letters[i] == active) C.BLUE else Color.WHITE
                c.drawText(letters[i].toString(), left + s * (i + 0.5f), height / 2f + off, paint)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (letters.isEmpty()) return true
                val n = letters.size
                val idx = if (!horizontal) {
                    val s = step(height)
                    ((e.y - (height - s * n) / 2f) / s).toInt()
                } else {
                    val s = step(width)
                    ((e.x - (width - s * n) / 2f) / s).toInt()
                }.coerceIn(0, n - 1)
                if (idx != last) {
                    last = idx
                    active = letters[idx]
                    onLetter?.invoke(letters[idx])
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { last = -1; return true }
        }
        return true
    }
}

class DrawerView(ctx: Context, private val app: LauncherApp) : FrameLayout(ctx) {
    sealed class Row {
        class Header(val title: String) : Row()
        class Item(val info: AppInfo) : Row()
    }

    val recycler = RecyclerView(ctx)
    private val strip = AlphabetStrip(ctx)
    private val pill = LinearLayout(ctx)
    private val hint = TextView(ctx)
    private val input = EditText(ctx)
    private var rows: List<Row> = emptyList()
    private val letterPos = HashMap<Char, Int>()
    private var horizontal = false
    private var searching = false
    private val adapter = Adapter()
    private var insL = 0
    private var insT = 0
    private var insR = 0
    private var insB = 0
    var isOpen = false
        private set
    var onOpenSettings: (() -> Unit)? = null
    var onOpenLauncherSettings: (() -> Unit)? = null
    var onAddToHome: ((AppRef) -> Unit)? = null
    var onLaunched: (() -> Unit)? = null

    init {
        setBackgroundColor(0xB8000000.toInt())
        visibility = GONE
        isClickable = true

        recycler.setHasFixedSize(true)
        recycler.itemAnimator = null
        recycler.clipToPadding = false
        recycler.adapter = adapter
        recycler.layoutManager = GridLayoutManager(ctx, 4)
        recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val lm = rv.layoutManager as? GridLayoutManager ?: return
                val p = lm.findFirstVisibleItemPosition()
                val r = rows.getOrNull(p)
                if (r is Row.Item) strip.active = r.info.letter
            }
        })
        addView(recycler, LayoutParams(MATCH, MATCH))

        strip.onLetter = { ch ->
            val pos = letterPos[ch]
            if (pos != null) (recycler.layoutManager as? GridLayoutManager)?.scrollToPositionWithOffset(pos, 0)
        }
        addView(strip, LayoutParams(dp(26), MATCH, Gravity.END))

        // bottom "Search for apps" pill
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = roundRect(0xCC4A4A4C.toInt(), dp(28f).toFloat())
        pill.setPadding(dp(14), 0, dp(8), 0)
        val searchIcon = ctx.iconView(R.drawable.ic_search, 0xFFDDDDDD.toInt())
        searchIcon.setOnClickListener { startSearch() }
        pill.addView(searchIcon, LinearLayout.LayoutParams(dp(26), dp(26)))
        val mid = FrameLayout(ctx)
        hint.text = "Search for apps"
        hint.textSize = 18f
        hint.setTextColor(0xFFE0E0E0.toInt())
        hint.gravity = Gravity.CENTER_VERTICAL
        hint.setPadding(dp(12), 0, 0, 0)
        hint.setOnClickListener { onOpenSettings?.invoke() }
        mid.addView(hint, LayoutParams(MATCH, MATCH))
        input.textSize = 18f
        input.setTextColor(Color.WHITE)
        input.background = null
        input.isSingleLine = true
        input.setPadding(dp(12), 0, 0, 0)
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.visibility = GONE
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { if (searching) refresh() }
        })
        input.setOnEditorActionListener { _, _, _ ->
            val first = rows.firstOrNull { it is Row.Item } as? Row.Item
            if (first != null) launch(first.info.ref)
            true
        }
        mid.addView(input, LayoutParams(MATCH, MATCH))
        pill.addView(mid, LinearLayout.LayoutParams(0, MATCH, 1f))
        val more = ctx.iconView(R.drawable.ic_more, 0xFFDDDDDD.toInt())
        more.setPadding(dp(8), dp(8), dp(8), dp(8))
        more.setOnClickListener { v ->
            val m = PopupMenu(context, v)
            m.menu.add(0, 1, 0, "Home Screen Mode")
            m.menu.add(0, 2, 1, "Settings")
            m.setOnMenuItemClickListener {
                if (it.itemId == 1) onOpenSettings?.invoke() else onOpenLauncherSettings?.invoke()
                true
            }
            m.show()
        }
        pill.addView(more, LinearLayout.LayoutParams(dp(40), dp(40)))
        addView(pill, LayoutParams(MATCH, dp(56), Gravity.BOTTOM))
        relayout()
    }

    fun setInsets(l: Int, t: Int, r: Int, b: Int) {
        insL = l; insT = t; insR = r; insB = b
        relayout()
    }

    private fun relayout() {
        val pillH = dp(56)
        val pillBottom = insB + dp(14)
        val pl = pill.layoutParams as LayoutParams
        pl.setMargins(insL + dp(16), 0, insR + dp(16), pillBottom)
        pill.layoutParams = pl

        val listBottom = pillBottom + pillH + dp(8)
        val rl = recycler.layoutParams as LayoutParams
        val sl = strip.layoutParams as LayoutParams
        if (horizontal) {
            rl.setMargins(insL, insT + dp(12), insR, listBottom + dp(28))
            sl.width = MATCH; sl.height = dp(28); sl.gravity = Gravity.BOTTOM
            sl.setMargins(insL + dp(12), 0, insR + dp(12), listBottom)
        } else {
            val showStrip = strip.visibility == VISIBLE
            rl.setMargins(insL, insT + dp(12), insR + if (showStrip) dp(8) else 0, listBottom)
            sl.width = dp(26); sl.height = MATCH; sl.gravity = Gravity.END
            sl.setMargins(0, insT + dp(12), insR, listBottom)
        }
        recycler.layoutParams = rl
        strip.layoutParams = sl
    }

    fun refresh() {
        val orientationH = app.prefs.mode == Prefs.MODE_AZ && app.prefs.azOrientation == 1 && !searching
        val q = if (searching) input.text.toString().trim().lowercase() else ""
        var list: List<AppInfo> = app.apps.apps
        if (q.isNotEmpty()) list = list.filter { it.label.lowercase().contains(q) }
        val classify = app.prefs.classification && !searching && !orientationH
        val out = ArrayList<Row>()
        if (classify) {
            val groups = list.groupBy { AppRepository.categoryName(it) }
            for (name in AppRepository.CATEGORY_ORDER) {
                val g = groups[name] ?: continue
                out.add(Row.Header(name))
                g.forEach { out.add(Row.Item(it)) }
            }
        } else {
            list.forEach { out.add(Row.Item(it)) }
        }
        rows = out
        letterPos.clear()
        out.forEachIndexed { i, r ->
            if (r is Row.Item && !letterPos.containsKey(r.info.letter)) letterPos[r.info.letter] = i
        }
        val az = app.prefs.mode == Prefs.MODE_AZ && !searching && !classify
        strip.visibility = if (az) VISIBLE else GONE
        strip.horizontal = orientationH
        strip.letters = letterPos.keys.sortedWith(compareBy<Char>({ it == '#' }, { it }))
        horizontal = orientationH
        val lm = if (orientationH) {
            GridLayoutManager(context, 6, RecyclerView.HORIZONTAL, false)
        } else {
            val g = GridLayoutManager(context, 4)
            g.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int =
                    if (rows.getOrNull(position) is Row.Header) 4 else 1
            }
            g
        }
        recycler.layoutManager = lm
        adapter.notifyDataSetChanged()
        relayout()
    }

    private fun launch(ref: AppRef) {
        Launch.start(context, ref)
        onLaunched?.invoke()
    }

    private fun startSearch() {
        if (searching) return
        searching = true
        hint.visibility = GONE
        input.visibility = VISIBLE
        input.requestFocus()
        post {
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }
        refresh()
    }

    private fun stopSearch() {
        if (!searching) return
        searching = false
        input.setText("")
        input.visibility = GONE
        hint.visibility = VISIBLE
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(windowToken, 0)
        refresh()
    }

    fun open(search: Boolean) {
        if (isOpen) {
            if (search) startSearch()
            return
        }
        isOpen = true
        refresh()
        visibility = VISIBLE
        alpha = 0f
        translationY = dp(60f).toFloat()
        animate().alpha(1f).translationY(0f).setDuration(220).start()
        if (search) post { startSearch() }
    }

    fun close() {
        if (!isOpen) return
        isOpen = false
        stopSearch()
        animate().alpha(0f).translationY(dp(60f).toFloat()).setDuration(180)
            .withEndAction { if (!isOpen) visibility = GONE }.start()
    }

    fun onBack(): Boolean {
        if (!isOpen) return false
        if (searching) { stopSearch(); return true }
        close()
        return true
    }

    private fun showMenu(anchor: View, ref: AppRef) {
        val m = PopupMenu(context, anchor)
        m.menu.add(0, 1, 0, "Add to Home screen")
        m.menu.add(0, 2, 1, "App info")
        m.menu.add(0, 3, 2, "Uninstall")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> onAddToHome?.invoke(ref)
                2 -> Launch.appInfo(context, ref.pkg)
                3 -> Launch.uninstall(context, ref.pkg)
            }
            true
        }
        m.show()
    }

    private inner class Adapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = rows.size
        override fun getItemViewType(position: Int): Int = if (rows[position] is Row.Header) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            if (viewType == 0) {
                val tv = TextView(context)
                tv.textSize = 15f
                tv.setTextColor(0xFFBDBDBD.toInt())
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.setPadding(dp(22), dp(14), 0, dp(4))
                tv.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
                return object : RecyclerView.ViewHolder(tv) {}
            }
            val sv = ShortcutView(context, app)
            if (horizontal) {
                val w = max(1, (parent.width - parent.paddingLeft - parent.paddingRight) / 4)
                val h = max(1, (parent.height - parent.paddingTop - parent.paddingBottom) / 6)
                sv.layoutParams = RecyclerView.LayoutParams(w, h)
            } else {
                sv.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
                sv.setPadding(dp(2), dp(12), dp(2), dp(10))
            }
            return object : RecyclerView.ViewHolder(sv) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val r = rows[position]
            if (r is Row.Header) {
                (holder.itemView as TextView).text = r.title
            } else if (r is Row.Item) {
                val sv = holder.itemView as ShortcutView
                val info = r.info
                sv.bindApp(info.ref, info.label)
                sv.setOnClickListener { launch(info.ref) }
                sv.setOnLongClickListener { showMenu(sv, info.ref); true }
            }
        }
    }
}
