package com.xlauncher.app.settings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.R
import com.xlauncher.app.data.Prefs
import com.xlauncher.app.ui.*

/** Phone-shaped illustration of a launcher mode. */
class PhonePreview(ctx: Context, private val az: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val inset = dp(2f).toFloat()
        val body = RectF(inset, inset, w - inset, h - inset)
        p.style = Paint.Style.FILL
        p.color = 0xFFEEF2F8.toInt()
        c.drawRoundRect(body, dp(16f).toFloat(), dp(16f).toFloat(), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = dp(2f).toFloat()
        p.color = 0xFF2A2A2E.toInt()
        c.drawRoundRect(body, dp(16f).toFloat(), dp(16f).toFloat(), p)
        p.style = Paint.Style.FILL

        val cols = 4
        val padX = w * 0.12f
        val cell = (w - padX * 2) / cols
        val s = cell * 0.62f
        if (!az) {
            for (r in 0 until 4) for (col in 0 until cols) {
                p.color = 0xFF9FB4D6.toInt()
                val cx = padX + col * cell + cell / 2
                val cy = h * 0.14f + r * cell * 1.25f
                c.drawRoundRect(RectF(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2), s * 0.3f, s * 0.3f, p)
            }
            p.color = 0xFFD5DCE8.toInt()
            c.drawRoundRect(RectF(w * 0.08f, h * 0.84f, w * 0.92f, h * 0.94f), dp(10f).toFloat(), dp(10f).toFloat(), p)
            for (col in 0 until cols) {
                p.color = 0xFF5B7FBF.toInt()
                val cx = padX + col * cell + cell / 2
                c.drawRoundRect(RectF(cx - s * 0.4f, h * 0.855f, cx + s * 0.4f, h * 0.925f), s * 0.2f, s * 0.2f, p)
            }
        } else {
            val gridCols = 3
            val cw = (w * 0.66f) / gridCols
            val sz = cw * 0.62f
            for (r in 0 until 5) for (col in 0 until gridCols) {
                p.color = 0xFF9FB4D6.toInt()
                val cx = w * 0.10f + col * cw + cw / 2
                val cy = h * 0.14f + r * cw * 1.3f
                c.drawRoundRect(RectF(cx - sz / 2, cy - sz / 2, cx + sz / 2, cy + sz / 2), sz * 0.3f, sz * 0.3f, p)
            }
            for (i in 0 until 10) {
                p.color = if (i == 0) C.BLUE else 0xFF7C8799.toInt()
                c.drawCircle(w * 0.90f, h * 0.14f + i * h * 0.07f, dp(1.8f).toFloat(), p)
            }
        }
    }
}

class HomeScreenModeActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as LauncherApp
        val prefs = app.prefs
        val body = scaffold("Home Screen Mode", bg = Color.WHITE, big = true)

        val classicDot = RadioDot(this)
        val azDot = RadioDot(this)
        lateinit var orientationCard: LinearLayout
        lateinit var orientationValue: TextView

        fun render() {
            val az = prefs.mode == Prefs.MODE_AZ
            classicDot.checked = !az
            azDot.checked = az
            orientationCard.visibility = if (az) View.VISIBLE else View.GONE
            orientationValue.text = if (prefs.azOrientation == 0) "Vertical" else "Horizontal"
        }

        fun option(name: String, az: Boolean, dot: RadioDot, onClick: () -> Unit): View {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(0, dp(8), 0, dp(8))
            col.setOnClickListener { onClick() }
            col.addView(PhonePreview(this, az), LinearLayout.LayoutParams(dp(110), dp(210)))
            col.addView(label(name, 16f, C.TEXT, true), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(12) })
            col.addView(dot, LinearLayout.LayoutParams(dp(24), dp(24)).apply { topMargin = dp(10) })
            return col
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(16), dp(4), dp(16), dp(8))
        row.addView(option("Classic Mode", false, classicDot) {
            prefs.mode = Prefs.MODE_CLASSIC
            render()
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(option("A-Z Mode", true, azDot) {
            prefs.mode = Prefs.MODE_AZ
            render()
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        // A-Z Screen Orientation (visible only in A-Z mode)
        orientationCard = card()
        val orow = settingRowDropdown("A-Z Screen Orientation") { anchor -> showOrientationPopup(anchor, prefs) { render() } }
        orientationValue = orow.findViewWithTag("value")
        orientationCard.addView(orow)
        body.addView(orientationCard)

        val c2 = card()
        c2.addView(switchRow("Add Newly Installed Apps to\nHome Screen", prefs.addNewApps) { prefs.addNewApps = it })
        body.addView(c2)
        val c3 = card()
        c3.addView(switchRow("App Classification", prefs.classification) { prefs.classification = it })
        body.addView(c3)

        render()
    }

    private fun settingRowDropdown(title: String, onClick: (View) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(20), dp(16), dp(16), dp(16))
        row.minimumHeight = dp(60)
        row.addView(label(title, 17f, C.TEXT), LinearLayout.LayoutParams(0, WRAP, 1f))
        val v = label("Vertical", 15f, C.GRAY)
        v.tag = "value"
        row.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(4) })
        row.addView(iconView(R.drawable.ic_dropdown, C.GRAY), LinearLayout.LayoutParams(dp(22), dp(22)))
        row.setOnClickListener { onClick(row) }
        return row
    }

    private fun showOrientationPopup(anchor: View, prefs: Prefs, changed: () -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = roundRect(Color.WHITE, dp(20f).toFloat())
        box.setPadding(0, dp(8), 0, dp(8))
        val popup = PopupWindow(box, dp(200), WRAP, true)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.elevation = dp(16f).toFloat()

        fun item(text: String, value: Int) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(20), 0, dp(16), 0)
            r.addView(label(text, 17f, C.TEXT), LinearLayout.LayoutParams(0, WRAP, 1f))
            if (prefs.azOrientation == value) {
                r.addView(iconView(R.drawable.ic_check, C.BLUE), LinearLayout.LayoutParams(dp(22), dp(22)))
            }
            r.setOnClickListener {
                prefs.azOrientation = value
                popup.dismiss()
                changed()
            }
            box.addView(r, LinearLayout.LayoutParams(MATCH, dp(52)))
        }
        item("Vertical", 0)
        item("Horizontal", 1)
        popup.showAsDropDown(anchor, 0, 0, Gravity.END)
    }
}
