package com.xlauncher.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import java.text.Collator

class AppInfo(val ref: AppRef, val label: String, val category: Int) {
    val letter: Char = run {
        val c = label.trim().firstOrNull()
        if (c == null) '#' else {
            val u = c.uppercaseChar()
            if (u in 'A'..'Z') u else '#'
        }
    }
}

class AppRepository(private val ctx: Context) {
    @Volatile
    var apps: List<AppInfo> = emptyList()
        private set
    @Volatile
    private var map: Map<AppRef, AppInfo> = emptyMap()

    fun reload() {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = try {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } catch (e: Exception) {
            emptyList()
        }
        val collator = Collator.getInstance()
        collator.strength = Collator.PRIMARY
        val out = list
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                AppInfo(
                    AppRef(ri.activityInfo.packageName, ri.activityInfo.name),
                    ri.loadLabel(pm).toString(),
                    ri.activityInfo.applicationInfo.category
                )
            }
            .sortedWith(Comparator { a, b ->
                val ga = if (a.letter == '#') 1 else 0
                val gb = if (b.letter == '#') 1 else 0
                if (ga != gb) ga - gb else collator.compare(a.label, b.label)
            })
        if (out.isNotEmpty()) {
            apps = out
            map = out.associateBy { it.ref }
        }
    }

    fun find(ref: AppRef): AppInfo? = map[ref]

    companion object {
        val CATEGORY_ORDER = listOf(
            "Games", "Social", "Music", "Video", "Photos", "News",
            "Maps & Travel", "Productivity", "Others"
        )

        fun categoryName(a: AppInfo): String = when (a.category) {
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_AUDIO -> "Music"
            ApplicationInfo.CATEGORY_VIDEO -> "Video"
            ApplicationInfo.CATEGORY_IMAGE -> "Photos"
            ApplicationInfo.CATEGORY_NEWS -> "News"
            ApplicationInfo.CATEGORY_MAPS -> "Maps & Travel"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            else -> "Others"
        }
    }
}
