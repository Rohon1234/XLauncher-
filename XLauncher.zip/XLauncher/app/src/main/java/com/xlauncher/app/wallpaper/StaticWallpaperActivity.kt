package com.xlauncher.app.wallpaper

import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xlauncher.app.ui.*

/** "My Wallpaper" > "Internal Wallpaper" grid. */
class StaticWallpaperActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val body = scaffold("My Wallpaper", scroll = false)
        val entries = WallpaperRepo.list(this)

        val head = label("Internal Wallpaper", 18f, C.TEXT, true)
        head.setPadding(dp(20), dp(6), dp(20), dp(10))
        body.addView(head)

        val sidePad = dp(16)
        val gap = dp(8)
        val colW = (resources.displayMetrics.widthPixels - sidePad * 2 - gap * 3) / 3
        val rv = RecyclerView(this)
        rv.layoutManager = GridLayoutManager(this, 3)
        rv.setPadding(sidePad - gap / 2, 0, sidePad - gap / 2, dp(24))
        rv.clipToPadding = false
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount(): Int = entries.size
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val iv = RoundImageView(this@StaticWallpaperActivity, dp(16f).toFloat())
                val lp = RecyclerView.LayoutParams(colW, (colW * 2.2f).toInt())
                lp.setMargins(gap / 2, gap / 2, gap / 2, gap / 2)
                iv.layoutParams = lp
                return object : RecyclerView.ViewHolder(iv) {}
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val e = entries[position]
                val iv = holder.itemView as ImageView
                Thumbs.load(this@StaticWallpaperActivity, e, iv)
                iv.setOnClickListener { applyEntryAndGoHome(e) }
            }
        }
        body.addView(rv, android.widget.LinearLayout.LayoutParams(MATCH, 0, 1f))
    }
}
