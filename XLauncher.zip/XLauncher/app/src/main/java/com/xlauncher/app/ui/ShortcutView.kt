package com.xlauncher.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.data.AppRef
import com.xlauncher.app.data.HomeItem

class ShortcutView(ctx: Context, private val app: LauncherApp) : LinearLayout(ctx) {
    val iconView = ImageView(ctx)
    val labelView = TextView(ctx)
    var selectable = false
        set(v) { field = v; invalidate() }
    var checked = false
        set(v) { field = v; invalidate() }
    private var boundRef: AppRef? = null
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val checkPath = Path()

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(2), dp(8), dp(2), dp(4))
        val scale = when (app.prefs.iconSize) { 0 -> 0.85f; 2 -> 1.15f; else -> 1f }
        val sz = dp(56f * scale)
        iconView.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(iconView, LayoutParams(sz, sz))
        labelView.textSize = 12f
        labelView.setTextColor(Color.WHITE)
        labelView.maxLines = 1
        labelView.ellipsize = TextUtils.TruncateAt.END
        labelView.gravity = Gravity.CENTER
        labelView.setShadowLayer(4f, 0f, 1f, 0x99000000.toInt())
        val lp = LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(6)
        addView(labelView, lp)
        isClickable = true
    }

    fun bindApp(ref: AppRef, name: String) {
        boundRef = ref
        labelView.text = name
        val cached = app.icons.peek(ref)
        if (cached != null) {
            iconView.setImageBitmap(cached)
        } else {
            iconView.setImageDrawable(null)
            app.icons.load(ref) { b -> if (boundRef == ref) iconView.setImageBitmap(b) }
        }
    }

    fun bindFolder(item: HomeItem) {
        boundRef = null
        labelView.text = item.title
        val bms = item.children.take(9).map { app.icons.loadSync(it) }
        iconView.setImageDrawable(FolderDrawable(bms))
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (!selectable) return
        val s = dp(18f).toFloat()
        val right = iconView.right + s * 0.25f
        val top = iconView.top - s * 0.35f
        val l = right - s
        val r = RectF(l, top, right, top + s)
        val rad = s * 0.28f
        if (checked) {
            badgePaint.style = Paint.Style.FILL
            badgePaint.color = C.BLUE
            canvas.drawRoundRect(r, rad, rad, badgePaint)
            badgePaint.style = Paint.Style.STROKE
            badgePaint.strokeWidth = dp(2f).toFloat()
            badgePaint.strokeCap = Paint.Cap.ROUND
            badgePaint.strokeJoin = Paint.Join.ROUND
            badgePaint.color = Color.WHITE
            checkPath.reset()
            checkPath.moveTo(l + s * 0.25f, top + s * 0.52f)
            checkPath.lineTo(l + s * 0.43f, top + s * 0.70f)
            checkPath.lineTo(l + s * 0.76f, top + s * 0.32f)
            canvas.drawPath(checkPath, badgePaint)
        } else {
            badgePaint.style = Paint.Style.FILL
            badgePaint.color = 0x66000000
            canvas.drawRoundRect(r, rad, rad, badgePaint)
            badgePaint.style = Paint.Style.STROKE
            badgePaint.strokeWidth = dp(1.5f).toFloat()
            badgePaint.color = 0xFFEDEDED.toInt()
            canvas.drawRoundRect(r, rad, rad, badgePaint)
        }
    }
}

class FolderDrawable(private val bitmaps: List<Bitmap>) : Drawable() {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB39E9E9E.toInt() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun draw(c: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        c.drawRoundRect(RectF(b), w * 0.24f, w * 0.24f, bg)
        val pad = w * 0.12f
        val gap = w * 0.04f
        val cs = (w - 2 * pad - 2 * gap) / 3
        bitmaps.forEachIndexed { i, bmp ->
            val col = i % 3
            val row = i / 3
            val l = b.left + pad + col * (cs + gap)
            val t = b.top + pad + row * (cs + gap)
            c.drawBitmap(bmp, null, RectF(l, t, l + cs, t + cs), p)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
