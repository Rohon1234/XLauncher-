package com.xlauncher.app.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors
import kotlin.math.max

class WallpaperEntry(val id: String, val assetPath: String?, val index: Int)

object WallpaperRepo {
    /** Built-in wallpapers: any images in assets/wallpapers plus the 19 generated ones. */
    fun list(ctx: Context): List<WallpaperEntry> {
        val out = mutableListOf<WallpaperEntry>()
        try {
            ctx.assets.list("wallpapers")?.sorted()?.forEach { n ->
                val l = n.lowercase()
                if (l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") || l.endsWith(".webp")) {
                    out.add(WallpaperEntry("asset:$n", "wallpapers/$n", -1))
                }
            }
        } catch (e: Exception) { }
        for (i in 0 until WallpaperFactory.COUNT) out.add(WallpaperEntry("gen:$i", null, i))
        return out
    }

    fun screenSize(ctx: Context): Pair<Int, Int> {
        val m = ctx.resources.displayMetrics
        return Pair(m.widthPixels, m.heightPixels)
    }

    fun centerCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val s = max(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * s
        val dh = src.height * s
        val dx = (w - dw) / 2f
        val dy = (h - dh) / 2f
        c.drawBitmap(src, null, RectF(dx, dy, dx + dw, dy + dh), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    private fun decodeAsset(ctx: Context, path: String, w: Int, h: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, opts) }
            ?: Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        return centerCrop(bmp, w, h)
    }

    fun render(ctx: Context, e: WallpaperEntry, w: Int, h: Int): Bitmap =
        if (e.assetPath != null) decodeAsset(ctx, e.assetPath, w, h) else WallpaperFactory.render(e.index, w, h)

    fun apply(ctx: Context, bmp: Bitmap): Boolean = try {
        WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_SYSTEM)
        true
    } catch (e: Exception) {
        false
    }
}

object Thumbs {
    private val cache = LruCache<String, Bitmap>(48)
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, e: WallpaperEntry, iv: ImageView, w: Int = 240, h: Int = 520) {
        iv.tag = e.id
        val hit = cache.get(e.id)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        val app = ctx.applicationContext
        pool.execute {
            val b = try { WallpaperRepo.render(app, e, w, h) } catch (ex: Exception) { null }
            if (b != null) {
                cache.put(e.id, b)
                main.post { if (iv.tag == e.id) iv.setImageBitmap(b) }
            }
        }
    }
}
