package com.xlauncher.app.ui

import android.content.Context
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ViewGroup
import com.xlauncher.app.data.HomeModel

class CellLayout(ctx: Context) : ViewGroup(ctx) {
    class LP(var cellX: Int, var cellY: Int, var spanX: Int, var spanY: Int) :
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    val cols = HomeModel.COLS
    val rows = HomeModel.ROWS
    var onEmptyLongPress: (() -> Unit)? = null
    var onEmptyTap: (() -> Unit)? = null

    private val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onLongPress(e: MotionEvent) { onEmptyLongPress?.invoke() }
        override fun onSingleTapUp(e: MotionEvent): Boolean { onEmptyTap?.invoke(); return true }
    })

    init {
        setPadding(dp(10), dp(10), dp(10), dp(10))
        clipChildren = false
    }

    fun setEdit(edit: Boolean) {
        background = if (edit) roundRect(0x59000000, dp(28f).toFloat()) else null
    }

    fun cellW(): Int = (width - paddingLeft - paddingRight) / cols
    fun cellH(): Int = (height - paddingTop - paddingBottom) / rows

    fun cellAt(x: Float, y: Float): Pair<Int, Int> {
        val cw = cellW().coerceAtLeast(1)
        val ch = cellH().coerceAtLeast(1)
        val cx = ((x - paddingLeft) / cw).toInt().coerceIn(0, cols - 1)
        val cy = ((y - paddingTop) / ch).toInt().coerceIn(0, rows - 1)
        return Pair(cx, cy)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        val cw = (w - paddingLeft - paddingRight) / cols
        val ch = (h - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val lp = v.layoutParams as LP
            v.measure(
                MeasureSpec.makeMeasureSpec(cw * lp.spanX, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch * lp.spanY, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (width - paddingLeft - paddingRight) / cols
        val ch = (height - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val lp = v.layoutParams as LP
            val left = paddingLeft + lp.cellX * cw
            val top = paddingTop + lp.cellY * ch
            v.layout(left, top, left + cw * lp.spanX, top + ch * lp.spanY)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        detector.onTouchEvent(event)
        return true
    }

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is LP
    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams = LP(0, 0, 1, 1)
    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = LP(0, 0, 1, 1)
}
