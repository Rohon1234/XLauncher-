package com.xlauncher.app.data

import org.json.JSONArray

class HomeModel(private val prefs: Prefs) {
    val items = mutableListOf<HomeItem>()

    fun load() {
        items.clear()
        val s = prefs.layout
        if (s.isEmpty()) return
        try {
            val arr = JSONArray(s)
            for (i in 0 until arr.length()) items.add(HomeItem.fromJson(arr.getJSONObject(i)))
        } catch (e: Exception) {
            items.clear()
        }
    }

    fun save() {
        val arr = JSONArray()
        for (i in items) arr.put(i.toJson())
        prefs.layout = arr.toString()
    }

    fun get(id: Long): HomeItem? = items.firstOrNull { it.id == id }

    fun pageCount(): Int = (items.maxOfOrNull { it.page } ?: 0) + 1

    fun itemsOn(page: Int): List<HomeItem> = items.filter { it.page == page }

    fun isFree(page: Int, x: Int, y: Int, sx: Int, sy: Int, ignore: Long = -1L): Boolean {
        if (x < 0 || y < 0 || x + sx > COLS || y + sy > ROWS) return false
        return items.none {
            it.page == page && it.id != ignore &&
                x < it.x + it.spanX && x + sx > it.x && y < it.y + it.spanY && y + sy > it.y
        }
    }

    fun itemAt(page: Int, x: Int, y: Int, ignore: Long = -1L): HomeItem? =
        items.firstOrNull {
            it.page == page && it.id != ignore &&
                x >= it.x && x < it.x + it.spanX && y >= it.y && y < it.y + it.spanY
        }

    fun findFree(page: Int, sx: Int, sy: Int): Pair<Int, Int>? {
        for (y in 0..(ROWS - sy)) for (x in 0..(COLS - sx)) {
            if (isFree(page, x, y, sx, sy)) return Pair(x, y)
        }
        return null
    }

    /** Sets page/x/y of [item] to the first free spot (does NOT add it to the list). */
    fun placeAnywhere(item: HomeItem, startPage: Int = 0) {
        val n = pageCount()
        val sp = startPage.coerceIn(0, n - 1)
        val order = (sp until n) + (0 until sp)
        for (p in order) {
            val f = findFree(p, item.spanX, item.spanY)
            if (f != null) {
                item.page = p; item.x = f.first; item.y = f.second
                return
            }
        }
        item.page = n; item.x = 0; item.y = 0
    }

    fun contains(ref: AppRef): Boolean =
        items.any { (it.type == HomeItem.APP && it.app == ref) || (it.type == HomeItem.FOLDER && ref in it.children) }

    fun addApp(ref: AppRef): HomeItem? {
        if (contains(ref)) return null
        val item = HomeItem(prefs.nextId(), HomeItem.APP, 0, 0, 0)
        item.app = ref
        placeAnywhere(item, pageCount() - 1)
        items.add(item)
        return item
    }

    fun removeById(id: Long) {
        items.removeAll { it.id == id }
    }

    fun removeMissing(keys: Set<String>) {
        if (keys.isEmpty()) return
        items.removeAll { it.type == HomeItem.APP && it.app?.key !in keys }
        for (f in items.filter { it.type == HomeItem.FOLDER }) f.children.removeAll { it.key !in keys }
        normalizeFolders()
    }

    fun normalizeFolders() {
        val it = items.iterator()
        while (it.hasNext()) {
            val f = it.next()
            if (f.type != HomeItem.FOLDER) continue
            if (f.children.isEmpty()) it.remove()
            else if (f.children.size == 1) {
                f.type = HomeItem.APP
                f.app = f.children[0]
                f.children.clear()
            }
        }
    }

    fun moveOutOfFolder(folder: HomeItem, ref: AppRef) {
        folder.children.remove(ref)
        val item = HomeItem(prefs.nextId(), HomeItem.APP, 0, 0, 0)
        item.app = ref
        placeAnywhere(item, folder.page)
        items.add(item)
        normalizeFolders()
    }

    fun compact() {
        val used = items.map { it.page }.distinct().sorted()
        val map = HashMap<Int, Int>()
        used.forEachIndexed { i, p -> map[p] = i }
        for (i in items) i.page = map[i.page] ?: 0
    }

    fun seed(all: List<AppInfo>) {
        items.clear()
        items.add(HomeItem(prefs.nextId(), HomeItem.CLOCK, 0, 0, 0, 4, 1))
        items.add(HomeItem(prefs.nextId(), HomeItem.SEARCH, 0, 0, 3, 4, 1))
        val used = HashSet<String>()

        fun addAt(a: AppInfo, x: Int, y: Int) {
            used.add(a.ref.key)
            val item = HomeItem(prefs.nextId(), HomeItem.APP, 0, x, y)
            item.app = a.ref
            items.add(item)
        }

        fun find(pkgs: List<String>): AppInfo? =
            pkgs.firstNotNullOfOrNull { p -> all.firstOrNull { it.ref.pkg == p && it.ref.key !in used } }

        fun fillRow(y: Int, wanted: List<List<String>>, cols: Int) {
            var x = 0
            for (w in wanted) {
                val a = find(w)
                if (a != null && x < cols) { addAt(a, x, y); x++ }
            }
            while (x < cols) {
                val a = all.firstOrNull { it.ref.key !in used } ?: break
                addAt(a, x, y); x++
            }
        }

        fillRow(
            1,
            listOf(
                listOf("com.android.vending"),
                listOf("com.google.android.apps.photos", "com.google.android.gallery3d", "com.sec.android.gallery3d", "com.android.gallery3d"),
                listOf("com.android.settings")
            ), 3
        )
        fillRow(
            4,
            listOf(
                listOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer", "com.google.android.contacts"),
                listOf("com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms"),
                listOf("com.android.chrome", "com.brave.browser", "org.mozilla.firefox", "com.sec.android.app.sbrowser"),
                listOf("com.google.android.GoogleCamera", "com.android.camera", "com.android.camera2", "com.sec.android.app.camera")
            ), 4
        )
    }

    companion object {
        const val COLS = 4
        const val ROWS = 6
    }
}
