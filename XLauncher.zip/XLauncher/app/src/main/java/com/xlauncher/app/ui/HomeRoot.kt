package com.xlauncher.app.ui

import android.content.Context
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.hypot

/** Root of the home screen: detects pinch (edit mode) and swipe-up (app drawer). */
class HomeRoot(ctx: Context) : FrameLayout(ctx) {
    var swipeUpAllowed: () -> Boolean = { true }
    var pinchAllowed: () -> Boolean = { true }
    var onSwipeUp: () -> Unit = {}
    /** true = pinch-in, false = pinch-out */
    var onPinch: (Boolean) -> Unit = {}

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var swiping = false
    private var pinching = false
    private var pinchFired = false
    private var startSpan = 0f
    private var vt: VelocityTracker? = null

    private fun span(e: MotionEvent): Float =
        hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))

    private fun reset() {
        swiping = false
        pinching = false
        pinchFired = false
        vt?.recycle()
        vt = null
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                swiping = false; pinching = false; pinchFired = false
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2 && pinchAllowed()) {
                    pinching = true
                    pinchFired = false
                    startSpan = span(e)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!swiping && e.pointerCount == 1 && swipeUpAllowed()) {
                    val dy = e.y - downY
                    val dx = e.x - downX
                    if (-dy > slop * 2 && abs(dy) > abs(dx) * 1.5f) {
                        swiping = true
                        return true
                    }
                }
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (pinching && e.pointerCount >= 2 && !pinchFired && startSpan > 0f) {
                    val r = span(e) / startSpan
                    if (r < 0.8f) { pinchFired = true; onPinch(true) }
                    else if (r > 1.25f) { pinchFired = true; onPinch(false) }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (swiping) {
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    val dy = downY - e.y
                    val vy = vt?.yVelocity ?: 0f
                    if (dy > dp(70) || vy < -1100f) onSwipeUp()
                }
                reset()
            }
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }
}
