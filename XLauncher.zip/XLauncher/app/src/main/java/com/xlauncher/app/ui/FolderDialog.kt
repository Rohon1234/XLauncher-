package com.xlauncher.app.ui

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.R
import com.xlauncher.app.data.AppRef
import com.xlauncher.app.data.HomeItem
import com.xlauncher.app.data.Launch
import kotlin.math.min

class FolderDialog(
    private val act: Activity,
    private val app: LauncherApp,
    private val folder: HomeItem,
    private val onChanged: () -> Unit
) {
    private lateinit var dialog: Dialog
    private lateinit var title: EditText
    private lateinit var grid: RecyclerView

    fun show() {
        dialog = Dialog(act, R.style.FolderDialog)
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.background = roundRect(0xEE2A2A2C.toInt(), act.dp(28f).toFloat())
        box.setPadding(act.dp(14), act.dp(16), act.dp(14), act.dp(18))

        title = EditText(act)
        title.setText(folder.title)
        title.setTextColor(Color.WHITE)
        title.textSize = 20f
        title.gravity = Gravity.CENTER
        title.background = null
        title.isSingleLine = true
        title.inputType = InputType.TYPE_CLASS_TEXT
        title.imeOptions = EditorInfo.IME_ACTION_DONE
        box.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))

        grid = RecyclerView(act)
        grid.layoutManager = GridLayoutManager(act, 4)
        grid.adapter = Adapter()
        val rowsN = (folder.children.size + 3) / 4
        val h = act.dp(100) * min(4, rowsN.coerceAtLeast(1))
        box.addView(grid, LinearLayout.LayoutParams(MATCH, h).apply { topMargin = act.dp(8) })

        dialog.setContentView(box)
        dialog.setOnDismissListener {
            val t = title.text.toString().trim()
            folder.title = if (t.isEmpty()) "Folder" else t
            app.model.save()
            onChanged()
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((act.resources.displayMetrics.widthPixels * 0.9f).toInt(), WRAP)
    }

    private inner class Adapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = folder.children.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val sv = ShortcutView(act, app)
            sv.layoutParams = RecyclerView.LayoutParams(MATCH, act.dp(100))
            return object : RecyclerView.ViewHolder(sv) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val ref: AppRef = folder.children[position]
            val sv = holder.itemView as ShortcutView
            sv.bindApp(ref, app.apps.find(ref)?.label ?: ref.pkg)
            sv.setOnClickListener {
                Launch.start(act, ref)
                dialog.dismiss()
            }
            sv.setOnLongClickListener {
                val m = PopupMenu(act, sv)
                m.menu.add(0, 1, 0, "Move to Home screen")
                m.menu.add(0, 2, 1, "Uninstall")
                m.setOnMenuItemClickListener { mi ->
                    if (mi.itemId == 1) {
                        app.model.moveOutOfFolder(folder, ref)
                        app.model.save()
                        onChanged()
                        if (folder.type != HomeItem.FOLDER || folder.children.isEmpty()) dialog.dismiss()
                        else grid.adapter?.notifyDataSetChanged()
                    } else {
                        Launch.uninstall(act, ref.pkg)
                    }
                    true
                }
                m.show()
                true
            }
        }
    }
}
