package com.xlauncher.app.data

import org.json.JSONArray
import org.json.JSONObject

data class AppRef(val pkg: String, val cls: String) {
    val key: String get() = "$pkg/$cls"
}

class HomeItem(
    var id: Long,
    var type: Int,
    var page: Int,
    var x: Int,
    var y: Int,
    var spanX: Int = 1,
    var spanY: Int = 1
) {
    var app: AppRef? = null
    var title: String = ""
    var widgetId: Int = -1
    val children: MutableList<AppRef> = mutableListOf()

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("t", type)
        o.put("p", page)
        o.put("x", x)
        o.put("y", y)
        o.put("sx", spanX)
        o.put("sy", spanY)
        o.put("title", title)
        o.put("wid", widgetId)
        val a = app
        if (a != null) {
            o.put("pkg", a.pkg)
            o.put("cls", a.cls)
        }
        if (children.isNotEmpty()) {
            val arr = JSONArray()
            for (c in children) arr.put(JSONObject().put("pkg", c.pkg).put("cls", c.cls))
            o.put("ch", arr)
        }
        return o
    }

    companion object {
        const val APP = 0
        const val FOLDER = 1
        const val WIDGET = 2
        const val SEARCH = 3
        const val CLOCK = 4

        fun fromJson(o: JSONObject): HomeItem {
            val item = HomeItem(
                o.getLong("id"), o.getInt("t"), o.getInt("p"), o.getInt("x"), o.getInt("y"),
                o.optInt("sx", 1), o.optInt("sy", 1)
            )
            item.title = o.optString("title", "")
            item.widgetId = o.optInt("wid", -1)
            if (o.has("pkg")) item.app = AppRef(o.getString("pkg"), o.getString("cls"))
            val arr = o.optJSONArray("ch")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    item.children.add(AppRef(c.getString("pkg"), c.getString("cls")))
                }
            }
            return item
        }
    }
}
