package com.xlauncher.app.wallpaper

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.R
import com.xlauncher.app.ui.*
import kotlin.math.max

/** Preview of an image picked from the gallery with an Apply button. */
class WallpaperPreviewActivity : ComponentActivity() {
    private var bitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val ctrl = WindowCompat.getInsetsController(window, window.decorView)
        ctrl.isAppearanceLightStatusBars = false
        ctrl.isAppearanceLightNavigationBars = false

        val uri = intent.data
        if (uri == null) { finish(); return }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))

        val back = iconView(R.drawable.ic_back, Color.WHITE)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.background = oval(0x66000000)
        back.setOnClickListener { finish() }
        val backLp = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.START)
        root.addView(back, backLp)

        val apply = TextView(this)
        apply.text = "Apply"
        apply.textSize = 17f
        apply.setTextColor(Color.WHITE)
        apply.typeface = android.graphics.Typeface.DEFAULT_BOLD
        apply.gravity = Gravity.CENTER
        apply.background = roundRect(C.BLUE, dp(28f).toFloat())
        val applyLp = FrameLayout.LayoutParams(dp(200), dp(54), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        root.addView(apply, applyLp)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            backLp.setMargins(b.left + dp(12), b.top + dp(12), 0, 0)
            back.layoutParams = backLp
            applyLp.bottomMargin = b.bottom + dp(28)
            apply.layoutParams = applyLp
            ins
        }
        setContentView(root)

        val (sw, sh) = WallpaperRepo.screenSize(this)
        Thread {
            val src = try {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val s = max(1, minOf(info.size.width / sw, info.size.height / sh))
                    dec.setTargetSampleSize(s)
                }
            } catch (e: Exception) {
                null
            }
            val cropped = src?.let { WallpaperRepo.centerCrop(it, sw, sh) }
            runOnUiThread {
                if (cropped == null) {
                    Toast.makeText(this, "Can't open image", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    bitmap = cropped
                    iv.setImageBitmap(cropped)
                }
            }
        }.start()

        apply.setOnClickListener {
            val b = bitmap ?: return@setOnClickListener
            Toast.makeText(this, "Applying...", Toast.LENGTH_SHORT).show()
            Thread {
                val ok = WallpaperRepo.apply(this, b)
                runOnUiThread {
                    if (ok) {
                        (application as LauncherApp).prefs.wallpaperId = "gallery"
                        goHome()
                    } else {
                        Toast.makeText(this, "Could not apply wallpaper", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
    }
}
