package com.xlauncher.app.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    var mode: Int
        get() = sp.getInt("mode", MODE_AZ)
        set(v) { sp.edit().putInt("mode", v).apply() }
    /** 0 = vertical, 1 = horizontal */
    var azOrientation: Int
        get() = sp.getInt("az_orientation", 0)
        set(v) { sp.edit().putInt("az_orientation", v).apply() }
    var addNewApps: Boolean
        get() = sp.getBoolean("add_new", true)
        set(v) { sp.edit().putBoolean("add_new", v).apply() }
    var classification: Boolean
        get() = sp.getBoolean("classify", false)
        set(v) { sp.edit().putBoolean("classify", v).apply() }
    /** 0 original, 1 circle, 2 squircle, 3 rounded square, 4 square */
    var iconStyle: Int
        get() = sp.getInt("icon_style", 0)
        set(v) { sp.edit().putInt("icon_style", v).apply() }
    /** 0 small, 1 medium, 2 large */
    var iconSize: Int
        get() = sp.getInt("icon_size", 1)
        set(v) { sp.edit().putInt("icon_size", v).apply() }
    var wallpaperId: String
        get() = sp.getString("wallpaper", "") ?: ""
        set(v) { sp.edit().putString("wallpaper", v).apply() }
    var layout: String
        get() = sp.getString("layout", "") ?: ""
        set(v) { sp.edit().putString("layout", v).apply() }
    var seeded: Boolean
        get() = sp.getBoolean("seeded", false)
        set(v) { sp.edit().putBoolean("seeded", v).apply() }
    var askedRole: Boolean
        get() = sp.getBoolean("asked_role", false)
        set(v) { sp.edit().putBoolean("asked_role", v).apply() }
    var knownApps: Set<String>
        get() = sp.getStringSet("known", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("known", HashSet(v)).apply() }

    fun nextId(): Long {
        val n = sp.getLong("next_id", 1L)
        sp.edit().putLong("next_id", n + 1).apply()
        return n
    }

    companion object {
        const val MODE_CLASSIC = 0
        const val MODE_AZ = 1
    }
}
