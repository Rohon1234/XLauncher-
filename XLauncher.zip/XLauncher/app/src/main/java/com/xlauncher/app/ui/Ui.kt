package com.xlauncher.app.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.xlauncher.app.R

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object C {
    const val BLUE = 0xFF1E6FFF.toInt()
    const val PAGE_BG = 0xFFF7F7F7.toInt()
    const val TEXT = 0xFF111111.toInt()
    const val GRAY = 0xFF8E8E93.toInt()
}

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dp(v: Int): Int = dp(v.toFloat())
fun View.dp(v: Float): Int = context.dp(v)
fun View.dp(v: Int): Int = context.dp(v.toFloat())

fun roundRect(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, strokeColor)
    }

fun oval(color: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(color)
}

fun Context.label(t: CharSequence, sp: Float, color: Int, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.iconView(res: Int, tint: Int? = null): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        if (tint != null) setColorFilter(tint)
    }

class RadioDot(ctx: Context) : View(ctx) {
    var checked = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        val s = context.dp(24)
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val sw = context.dp(2).toFloat()
        val r = width / 2f - sw
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.color = if (checked) C.BLUE else 0xFFB0B0B5.toInt()
        c.drawCircle(cx, cy, r, p)
        if (checked) {
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, r - context.dp(4), p)
        }
    }
}

/** Standard light settings page: back arrow + title + body container. */
fun ComponentActivity.scaffold(
    title: String,
    bg: Int = C.PAGE_BG,
    scroll: Boolean = true,
    big: Boolean = false
): LinearLayout {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    val ctrl = WindowCompat.getInsetsController(window, window.decorView)
    ctrl.isAppearanceLightStatusBars = true
    ctrl.isAppearanceLightNavigationBars = true
    val root = LinearLayout(this)
    root.orientation = LinearLayout.VERTICAL
    root.setBackgroundColor(bg)
    val back = iconView(R.drawable.ic_back, C.TEXT)
    back.setPadding(dp(10), dp(10), dp(10), dp(10))
    back.setOnClickListener { finish() }
    if (big) {
        val lp = LinearLayout.LayoutParams(dp(48), dp(48))
        lp.setMargins(dp(12), dp(8), 0, 0)
        root.addView(back, lp)
        val t = label(title, 32f, C.TEXT, true)
        t.setPadding(dp(24), dp(8), dp(24), dp(16))
        root.addView(t)
    } else {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(12), dp(14), dp(12), dp(10))
        bar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        val t = label(title, 22f, C.TEXT, true)
        t.setPadding(dp(8), 0, 0, 0)
        bar.addView(t)
        root.addView(bar)
    }
    val body = LinearLayout(this)
    body.orientation = LinearLayout.VERTICAL
    if (scroll) {
        val sv = ScrollView(this)
        sv.addView(body, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    } else {
        root.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }
    ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
        val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
        v.setPadding(b.left, b.top, b.right, b.bottom)
        ins
    }
    setContentView(root)
    return body
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = roundRect(Color.WHITE, dp(20).toFloat())
    val lp = LinearLayout.LayoutParams(MATCH, WRAP)
    lp.setMargins(dp(16), dp(8), dp(16), dp(8))
    c.layoutParams = lp
    return c
}

/** Row with title, optional value text and a chevron. The value TextView has tag "value". */
fun Context.settingRow(title: String, value: String? = null, onClick: () -> Unit): LinearLayout {
    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(20), dp(16), dp(16), dp(16))
    row.minimumHeight = dp(60)
    row.setOnClickListener { onClick() }
    row.addView(label(title, 17f, C.TEXT), LinearLayout.LayoutParams(0, WRAP, 1f))
    if (value != null) {
        val v = label(value, 15f, C.GRAY)
        v.tag = "value"
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.rightMargin = dp(6)
        row.addView(v, lp)
    }
    row.addView(iconView(R.drawable.ic_chevron, C.GRAY), LinearLayout.LayoutParams(dp(20), dp(20)))
    return row
}

fun Context.switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
    val row = LinearLayout(this)
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(20), dp(12), dp(20), dp(12))
    row.minimumHeight = dp(64)
    val sw = Switch(this)
    sw.isChecked = checked
    sw.thumbTintList = ColorStateList.valueOf(Color.WHITE)
    sw.trackTintList = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
        intArrayOf(C.BLUE, 0xFFC7C7CC.toInt())
    )
    sw.setOnCheckedChangeListener { _, v -> onChange(v) }
    row.setOnClickListener { sw.toggle() }
    val t = label(title, 17f, C.TEXT)
    row.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(12) })
    row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
    return row
}
