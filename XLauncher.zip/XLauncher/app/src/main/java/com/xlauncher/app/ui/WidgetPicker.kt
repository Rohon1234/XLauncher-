package com.xlauncher.app.ui

import android.app.Activity
import android.app.Dialog
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.xlauncher.app.R
import kotlin.math.ceil

/** Bottom sheet listing every installed AppWidget provider. */
class WidgetPicker(
    private val act: Activity,
    private val awm: AppWidgetManager,
    private val onPick: (AppWidgetProviderInfo) -> Unit
) {
    fun show() {
        val pm = act.packageManager
        val providers = awm.installedProviders.sortedBy { it.loadLabel(pm).lowercase() }
        val d = Dialog(act, R.style.FolderDialog)
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        val r = act.dp(28f).toFloat()
        box.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFFF2F2F4.toInt())
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        box.setPadding(act.dp(12), act.dp(16), act.dp(12), 0)
        box.addView(
            act.label("Widgets", 22f, C.TEXT, true).apply { setPadding(act.dp(12), 0, 0, act.dp(10)) },
            LinearLayout.LayoutParams(MATCH, WRAP)
        )
        val rv = RecyclerView(act)
        rv.layoutManager = LinearLayoutManager(act)
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount(): Int = providers.size
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val row = LinearLayout(act)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(act.dp(12), act.dp(10), act.dp(12), act.dp(10))
                row.layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
                val iv = ImageView(act)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                iv.tag = "img"
                row.addView(iv, LinearLayout.LayoutParams(act.dp(96), act.dp(64)))
                val col = LinearLayout(act)
                col.orientation = LinearLayout.VERTICAL
                col.tag = "col"
                row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = act.dp(14) })
                return object : RecyclerView.ViewHolder(row) {}
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val p = providers[position]
                val row = holder.itemView as LinearLayout
                val iv = row.findViewWithTag<ImageView>("img")
                val col = row.findViewWithTag<LinearLayout>("col")
                val dm = act.resources.displayMetrics
                val img = try { p.loadPreviewImage(act, 0) ?: p.loadIcon(act, 0) } catch (e: Exception) { null }
                iv.setImageDrawable(img)
                col.removeAllViews()
                col.addView(act.label(p.loadLabel(act.packageManager), 16f, C.TEXT, true))
                val cx = ceil(p.minWidth / (dm.widthPixels / 4f)).toInt().coerceIn(1, 4)
                val cy = ceil(p.minHeight / (dm.heightPixels / 8f)).toInt().coerceIn(1, 6)
                col.addView(act.label("${cx} x ${cy}", 13f, C.GRAY))
                row.setOnClickListener {
                    d.dismiss()
                    onPick(p)
                }
            }
        }
        box.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        d.setContentView(box)
        d.show()
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setGravity(Gravity.BOTTOM)
        d.window?.setLayout(MATCH, (act.resources.displayMetrics.heightPixels * 0.72f).toInt())
    }
}
