package com.xlauncher.app.settings

import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import com.xlauncher.app.LauncherApp
import com.xlauncher.app.data.Prefs
import com.xlauncher.app.ui.*
import com.xlauncher.app.wallpaper.WallpapersActivity

class SettingsActivity : ComponentActivity() {
    private lateinit var modeValue: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as LauncherApp
        val prefs = app.prefs
        val body = scaffold("Settings")

        val c1 = card()
        val modeRow = settingRow("Home Screen Mode", modeText(prefs)) {
            startActivity(Intent(this, HomeScreenModeActivity::class.java))
        }
        modeValue = modeRow.findViewWithTag("value")
        c1.addView(modeRow)
        c1.addView(switchRow("Add Newly Installed Apps to\nHome Screen", prefs.addNewApps) { prefs.addNewApps = it })
        c1.addView(switchRow("App Classification", prefs.classification) { prefs.classification = it })
        body.addView(c1)

        val c2 = card()
        c2.addView(settingRow("Wallpapers") { startActivity(Intent(this, WallpapersActivity::class.java)) })
        c2.addView(settingRow("Icon Style") { startActivity(Intent(this, IconStyleActivity::class.java)) })
        body.addView(c2)

        val c3 = card()
        c3.addView(settingRow("Set as default launcher") {
            try {
                val rm = getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                }
            } catch (e: Exception) { }
        })
        body.addView(c3)
    }

    override fun onResume() {
        super.onResume()
        modeValue.text = modeText((application as LauncherApp).prefs)
    }

    private fun modeText(p: Prefs): String = if (p.mode == Prefs.MODE_AZ) "A-Z Mode" else "Classic Mode"
}
