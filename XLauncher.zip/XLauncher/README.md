# XLauncher
GitHub-এ push করুন -> Actions -> "Build APK" -> Artifacts থেকে APK ডাউনলোড।
Android 13-16 (minSdk 33). Real wallpapers দিতে চাইলে png/jpg/webp ফাইল `app/src/main/assets/wallpapers/` ফোল্ডারে রাখুন, Static Wallpapers-এ নিজে থেকে যোগ হবে।
